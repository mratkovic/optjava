package hr.fer.zemris.optjava.dz13.ant.gui;

public class AntRestartException extends RuntimeException {

    private static final long serialVersionUID = 1L;

}
