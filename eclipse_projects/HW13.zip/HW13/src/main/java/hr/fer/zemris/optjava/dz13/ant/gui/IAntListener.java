package hr.fer.zemris.optjava.dz13.ant.gui;

import hr.fer.zemris.optjava.dz13.ant.Ant;

public interface IAntListener {
    void update(Ant source);
}
