package hr.fer.zemris.optjava.ga;

public interface IFunction<T> {

    public double valueAt(T point);

}
