package hr.fer.zemris.optimizations.ann;

public interface ITransferFunction {

    public double valueAt(double net);

}
