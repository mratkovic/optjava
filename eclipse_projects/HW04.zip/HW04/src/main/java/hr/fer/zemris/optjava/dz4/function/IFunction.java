package hr.fer.zemris.optjava.dz4.function;

public interface IFunction {

    public double valueAt(double[] values);

}
