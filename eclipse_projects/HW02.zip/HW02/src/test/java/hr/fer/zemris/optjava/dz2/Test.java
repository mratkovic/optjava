package hr.fer.zemris.optjava.dz2;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class Test extends TestCase {

    public void test() {
        assertTrue(true);
    }
}
