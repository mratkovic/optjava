My solutions:

ATT48
ro = 0.018;
3000 iterations
Distance = 33856.773

BAYS29:
ro = 0.008;
3000 iterations
Distance = 9094.635

CH150: 
ro = 0.008;
2000 iterations
Distance = 6746.6113

pr2392:
	TLE
