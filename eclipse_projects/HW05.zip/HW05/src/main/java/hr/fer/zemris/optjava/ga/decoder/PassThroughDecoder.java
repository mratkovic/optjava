package hr.fer.zemris.optjava.ga.decoder;

import hr.fer.zemris.optjava.ga.solution.BitVectorSolution;

public class PassThroughDecoder implements IDecoder<BitVectorSolution> {
    @Override
    public double[] decode(final BitVectorSolution value) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void decode(final BitVectorSolution value, final double[] values) {
        // TODO Auto-generated method stub

    }

    @Override
    public void printSolution(final BitVectorSolution best) {
        // TODO Auto-generated method stub

    }

}
