Defaultni parametri zadani u razredima s main metodom:
	hr.fer.zemris.optjava.dz5.part1.GeneticAlgorithm
	hr.fer.zemris.optjava.dz5.part2.GeneticAlgorithm

Tu je moguce eksperimentirati s parametrima. 
Nisam stavio da se zadaju preko komandne linije.
	

## Odgovori
Velicina turnira kod turnirske selekcije mi utjece  na brzinu konvergencije 
(veci turnir -> veca sansa da se bolje jednike odaberu -> veci selekcijski pritisak).

Bolje rezultate dobivam kad su oba roditelja birana turnirom (naspram slucajnog odabira).
