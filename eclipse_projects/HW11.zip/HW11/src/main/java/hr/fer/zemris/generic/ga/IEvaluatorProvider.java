package hr.fer.zemris.generic.ga;

public interface IEvaluatorProvider {

    public Evaluator getEvaluator();
}
