package hr.fer.zemris.optjava.rng;

public interface IRNGProvider {
    public IRNG getRNG();
}