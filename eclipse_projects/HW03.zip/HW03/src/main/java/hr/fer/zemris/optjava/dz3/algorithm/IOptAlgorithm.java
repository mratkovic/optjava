package hr.fer.zemris.optjava.dz3.algorithm;

public interface IOptAlgorithm<T> {

    public void run();

}