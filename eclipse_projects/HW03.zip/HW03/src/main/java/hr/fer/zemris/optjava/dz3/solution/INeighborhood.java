package hr.fer.zemris.optjava.dz3.solution;

public interface INeighborhood<T> {

    public T randomNeighbor(T neighbor);

}
